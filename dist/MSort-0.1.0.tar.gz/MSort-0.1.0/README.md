# MSort

MSort is a Python library that provides implementations of three different sorting algorithms: Bubble Sort, Quick Sort, and Merge Sort.

## Installation

You can install MSort using pip:

```bash
pip install MSort
